from django.contrib import admin
from .models import Equipment, Filler
# Register your models here.
admin.site.register(Equipment)
admin.site.register(Filler)
